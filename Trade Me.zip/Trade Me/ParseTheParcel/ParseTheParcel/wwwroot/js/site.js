﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.



function calculateOutput() {

    // Store user inputs for breadth, height and length //

    var breadth = $("#breadth").val();
    var height = $("#height").val();
    var length = $("#length").val();

    // Calculate the weight of the known parcel dimensions. //

    var smallParcelWeight = ((300 * 200 * 150) / 6000)/1000; // formula weight = ((b * l * h)/ 6000) in mm.//
    var mediumParcelWeight = ((400 * 300 * 200) / 6000)/1000;
    var largeParcelWeight = ((600 * 400 * 250) / 6000)/1000;
    var maxParcelWeight = 25000/1000; 

    var weight = Math.round((((breadth * length * height) / 6000) / 1000) * 100) / 100;

    // Cost of parcels //

    var smallParcelCost = "$5.00";
    var mediumParcelCost = "$7.50";
    var largeParcelCost = "$8.50";


    // Calcuate the weight of parcel dimensions entered //

    var result;

    var output;
   
    output = "The weight for this parcel is " + weight + " kgs.";    


    // Determine output: package size and cost and whether it can be sent or not //
    
    if (weight == smallParcelWeight) {

        result = "This is a small parcel." + " The cost will be " + smallParcelCost + ". ";
    } else if (weight == mediumParcelWeight) {
        result = "This is a medium parcel." + " The cost will be " + mediumParcelCost + ". ";

    } else if (weight == largeParcelWeight) {

        result = "This is a large parcel." + " The cost will be " + largeParcelCost + ". ";

    }

    else if (weight < smallParcelWeight) { // If weight is less than or equal to the set small parcel weight, then this is a small parcel//


        result = "This is a small parcel." + " The cost will be a maximum of " + smallParcelCost + ". ";

    } else if (weight > smallParcelWeight && weight < mediumParcelWeight) { // if weight is less than set medium parcel or greater than the small parcel, then it is between small and medium //


        result = "This is a small-medium parcel." + " The cost will be between " + smallParcelCost + " and " + mediumParcelCost + ". ";

    }
    else if (weight > mediumParcelWeight && weight < largeParcelWeight) { // if weight is less than set large parcel or greater than the medium parcel, then it is between medium and large // 


        result = "This is a medium-large parcel." + " The cost will be between " + smallParcelCost + " and " + mediumParcelCost + ". ";

    }

    else if (weight > maxParcelWeight) { // If the weight of the parcel exceeds 25kg, it cannot be sent. //

 
        result = "Sorry we cannot send this parcel. This parcel weighs more than 25kg. ";
    }

    else if (weight > largeParcelWeight) { // If the weight is greater than or equal to the set large parcel size then it is a large parcel. //


        result = "This is a large parcel." + " The cost will be a minimum of " + largeParcelCost + ". ";
    } 
    
    // Store result in div to show on screen //

    if (weight < 0) {

        $('#outputDiv').text("Please enter valid dimensions");
    } else {
        $('#outputDiv').text(result + output);
    }

    
}